import { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, Text, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import { Brand } from '@/components/Brand';
import { PrimaryButton } from '@/components/PrimaryButton';
import { colors } from '@/constants/theme';
import { supabase } from '@/lib/supabase';

export default function Welcome() {
  const [mode,setMode]=useState<'signin'|'signup'>('signin');
  const [name,setName]=useState(''); const [email,setEmail]=useState('');
  const [phone,setPhone]=useState(''); const [password,setPassword]=useState('');
  const [loading,setLoading]=useState(false);
  const submit=async()=>{
    if(!email.trim()||password.length<8||(mode==='signup'&&(!name.trim()||!phone.trim()))) {
      Alert.alert('Check your details','Enter your email and password (at least 8 characters). Sign-up also needs your name and phone number.'); return;
    }
    setLoading(true);
    try {
      if(mode==='signup') {
        const {error}=await supabase.auth.signUp({email:email.trim(),password,options:{data:{full_name:name.trim(),phone:phone.trim()}}});
        if(error) throw error;
        Alert.alert('Account request submitted','Check your email for a confirmation message if email confirmation is enabled.');
      } else {
        const {error}=await supabase.auth.signInWithPassword({email:email.trim(),password});
        if(error) throw error;
        router.replace('/(tabs)');
      }
    } catch(e) { Alert.alert('Could not continue',e instanceof Error?e.message:'Please try again.'); }
    finally {setLoading(false);}
  };
  const field=(label:string,value:string,set:(v:string)=>void,props:any={})=><View style={{gap:7}}>
    <Text style={{color:colors.muted,fontSize:13,fontWeight:'700'}}>{label}</Text>
    <TextInput value={value} onChangeText={set} placeholder={label} placeholderTextColor="#777"
      autoCapitalize="none" style={{backgroundColor:colors.surface,borderColor:colors.border,borderWidth:1,borderRadius:12,padding:15,color:colors.text,fontSize:16}} {...props}/>
  </View>;
  return <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1,backgroundColor:colors.background,justifyContent:'center',padding:24,gap:24}}>
    <Brand />
    <View style={{gap:16}}>
      <Text style={{color:colors.text,fontSize:25,fontWeight:'900',textAlign:'center'}}>{mode==='signin'?'Welcome back':'Create your account'}</Text>
      <Text style={{color:colors.muted,textAlign:'center'}}>Delivering more. Living easier.</Text>
      {mode==='signup'&&<>{field('Full name',name,setName)}{field('Mobile phone',phone,setPhone,{keyboardType:'phone-pad'})}</>}
      {field('Email address',email,setEmail,{keyboardType:'email-address'})}
      {field('Password',password,setPassword,{secureTextEntry:true,autoCapitalize:'none'})}
      <PrimaryButton title={mode==='signin'?'Sign in':'Create account'} onPress={submit} loading={loading}/>
      <Pressable onPress={()=>setMode(mode==='signin'?'signup':'signin')}><Text style={{color:colors.goldLight,textAlign:'center',fontWeight:'700'}}>{mode==='signin'?"New to Crazy Cash? Create an account":"Already registered? Sign in"}</Text></Pressable>
      <Pressable onPress={()=>router.push('/roles')}><Text style={{color:colors.text,textAlign:'center',fontWeight:'700'}}>Continue as guest / view other portals</Text></Pressable>
      <Text style={{color:colors.muted,fontSize:11,textAlign:'center'}}>Phone verification and SMS login will be enabled after the SMS provider is configured.</Text>
    </View>
  </KeyboardAvoidingView>;
}
