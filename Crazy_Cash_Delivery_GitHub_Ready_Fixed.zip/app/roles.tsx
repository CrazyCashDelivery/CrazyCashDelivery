import { ScrollView, Text, View, Pressable } from 'react-native';
import { router } from 'expo-router';
import { Brand } from '@/components/Brand';
import { colors } from '@/constants/theme';

const roles = [
  { icon:'🛍️', title:'Customer', detail:'Explore delivery services and manage orders.', route:'/(tabs)' },
  { icon:'🚗', title:'Driver', detail:'Driver onboarding, availability, and delivery offers.', route:'/driver' },
  { icon:'🏪', title:'Merchant', detail:'Business onboarding, store details, and incoming orders.', route:'/merchant' },
  { icon:'🛡️', title:'Admin', detail:'Operations, approvals, safety, and platform oversight.', route:'/admin' },
];

export default function Roles() {
  return <ScrollView style={{flex:1,backgroundColor:colors.background}} contentContainerStyle={{padding:24,paddingTop:58,gap:22}}>
    <Brand />
    <View style={{gap:7}}>
      <Text style={{color:colors.text,fontSize:27,fontWeight:'900',textAlign:'center'}}>Choose your portal</Text>
      <Text style={{color:colors.muted,textAlign:'center',lineHeight:21}}>One delivery platform. Different tools for every role.</Text>
    </View>
    {roles.map((r)=><Pressable key={r.title} onPress={()=>router.push(r.route as any)} style={{backgroundColor:colors.surface,borderWidth:1,borderColor:colors.border,borderRadius:17,padding:18,flexDirection:'row',gap:15,alignItems:'center'}}>
      <Text style={{fontSize:30}}>{r.icon}</Text>
      <View style={{flex:1,gap:5}}>
        <Text style={{color:colors.gold,fontSize:18,fontWeight:'900'}}>{r.title}</Text>
        <Text style={{color:colors.muted,lineHeight:19}}>{r.detail}</Text>
      </View>
      <Text style={{color:colors.gold,fontSize:22}}>›</Text>
    </Pressable>)}
    <Text style={{color:colors.muted,fontSize:12,lineHeight:18}}>Each portal now connects to its protected Supabase workflows. Driver and merchant actions require approval; administrator actions require an authorized staff account.</Text>
    <Pressable onPress={()=>router.replace('/welcome')}><Text style={{color:colors.goldLight,textAlign:'center',fontWeight:'800'}}>Back to sign in</Text></Pressable>
  </ScrollView>;
}
