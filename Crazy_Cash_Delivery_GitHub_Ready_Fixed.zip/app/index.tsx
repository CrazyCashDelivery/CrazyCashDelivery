import { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { colors } from '@/constants/theme';

export default function Index() {
  const [checking, setChecking] = useState(true);
  useEffect(() => {
    let alive = true;
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      if (!alive) return;
      if (event === 'SIGNED_IN' && session) router.replace('/(tabs)');
      if (event === 'SIGNED_OUT') router.replace('/welcome');
    });

    const resolveInitialRoute = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) throw error;
        if (alive) router.replace(data.session ? '/(tabs)' : '/welcome');
      } catch (error) {
        console.warn('Unable to restore the saved session:', error);
        if (alive) router.replace('/welcome');
      } finally {
        if (alive) setChecking(false);
      }
    };

    void resolveInitialRoute();
    return () => { alive = false; listener.subscription.unsubscribe(); };
  }, []);
  return <View style={{ flex:1, alignItems:'center', justifyContent:'center', backgroundColor:colors.background }}>
    <ActivityIndicator color={colors.gold} size="large" />
  </View>;
}
