import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/constants/theme';
export default function TabLayout() {
  return <Tabs screenOptions={{headerShown:false,tabBarStyle:{backgroundColor:'#111',borderTopColor:colors.border},tabBarActiveTintColor:colors.gold,tabBarInactiveTintColor:colors.muted}}>
    <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:({color,size})=><Ionicons name="home-outline" color={color} size={size}/>}}/>
    <Tabs.Screen name="orders" options={{title:'Orders',tabBarIcon:({color,size})=><Ionicons name="receipt-outline" color={color} size={size}/>}}/>
    <Tabs.Screen name="account" options={{title:'Account',tabBarIcon:({color,size})=><Ionicons name="person-outline" color={color} size={size}/>}}/>
  </Tabs>;
}
