import { useCallback, useEffect, useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { PrimaryButton } from '@/components/PrimaryButton';
import { colors } from '@/constants/theme';
import { supabase } from '@/lib/supabase';

type AccountInfo = { email: string; isGuest: boolean };

export default function Account() {
 const [account,setAccount]=useState<AccountInfo>({email:'',isGuest:false});
 const [loading,setLoading]=useState(true);
 const load=useCallback(async()=>{
  setLoading(true);
  try {
   const {data,error}=await supabase.auth.getUser();
   if(error) throw error;
   setAccount({email:data.user?.email??'',isGuest:!!data.user?.is_anonymous});
  } catch(error) {
   Alert.alert('Account',error instanceof Error?error.message:'Could not load account details.');
  } finally { setLoading(false); }
 },[]);
 useEffect(()=>{void load();},[load]);
 const signOut=()=>Alert.alert(
  'Sign out?',
  account.isGuest
   ? 'This is a temporary guest account. Signing out may permanently remove access to orders saved in this guest session. Continue only if you no longer need those orders.'
   : 'You can sign back in later to access your account.',
  [
   {text:'Stay signed in',style:'cancel'},
   {text:'Sign out',style:'destructive',onPress:async()=>{
    const {error}=await supabase.auth.signOut();
    if(error) Alert.alert('Sign out failed',error.message);
   }}
  ]
 );
 return <View style={{flex:1,backgroundColor:colors.background,padding:24,paddingTop:70,gap:18}}>
  <Text style={{color:colors.gold,fontSize:13,fontWeight:'900',letterSpacing:2}}>MY ACCOUNT</Text>
  <Text style={{color:colors.text,fontSize:25,fontWeight:'900'}}>Account details</Text>
  <Text style={{color:colors.muted}}>Account type</Text>
  <Text style={{color:colors.text,fontSize:16}}>{loading?'Loading…':account.isGuest?'Guest session':'Registered account'}</Text>
  <Text style={{color:colors.muted}}>Email</Text>
  <Text style={{color:colors.text,fontSize:16}}>{loading?'Loading…':account.email||'Not provided'}</Text>
  {account.isGuest&&<View style={{backgroundColor:colors.surface,borderColor:colors.border,borderWidth:1,borderRadius:12,padding:14,gap:6}}>
   <Text style={{color:colors.gold,fontWeight:'900'}}>Protect your guest orders</Text>
   <Text style={{color:colors.muted,lineHeight:21}}>Your orders are linked to this temporary session on this device. Do not sign out, clear app data, or delete the app until you no longer need access to those orders.</Text>
  </View>}
  <View style={{height:1,backgroundColor:colors.border,marginVertical:10}}/>
  <Text style={{color:colors.muted,lineHeight:21}}>Driver and merchant applications are available from their portals. VIP membership, saved addresses, and support settings are still being completed.</Text>
  <PrimaryButton title="Sign out" onPress={signOut}/>
 </View>;
}
