# Crazy Cash Delivery — backend security review

Review date: 2026-11-06. This review used read-only inspection of the connected Supabase project. No database policies, Auth settings, or Edge Functions were changed or deployed during this pass.

## Confirmed findings

- Row Level Security is enabled on the inspected public tables (`customers`, `drivers`, `merchants`, `orders`, `admin_users`, role applications, catalog, directory, and notification events).
- The `admin_users` client SELECT policy has `USING (false)`, so the anonymous-access advisor warning for that table does not mean client reads are permitted.
- Customer profile and order SELECT policies scope rows to `auth.uid()` ownership. The driver and merchant profile SELECT policies also scope rows to the matching `auth_user_id`.
- Anonymous Auth sessions use the `authenticated` Postgres role. The existing owner-scoped customer policies therefore permit a guest session to see/update only its own customer profile and read only its own orders. This is consistent with guest checkout, but it must remain tightly ownership-scoped.
- Supabase reports leaked-password protection as disabled. This should be enabled in the Supabase Auth password security settings before public account launch.
- The performance advisor reports 13 currently unused indexes. They were not removed because the product is pre-launch and those indexes may support expected query paths.

## Fix prepared, not deployed

The deployed `submit-role-application` function checked that the phone field was present but did not enforce the same 10–15 digit phone rule as the mobile form. A hardened source copy is included at `supabase/functions/submit-role-application/index.ts`; it adds server-side phone validation so a caller cannot bypass the form check by calling the endpoint directly.

**Important:** this is a local source patch only. The production Edge Function remains unchanged until the owner explicitly approves deployment and the function is verified after deployment.

## Remaining security actions

1. Enable leaked-password protection in Supabase Auth and test registration/password reset.
2. Review guest-session ownership behavior and confirm guest order access is not shared across devices or sessions.
3. Keep all admin authorization based on the protected `admin_users` registry or trusted app metadata, never user-editable profile metadata.
4. Test the updated application endpoint with valid and invalid phone inputs after a controlled deployment.
5. Review all RLS policies and Edge Function ownership checks before opening customer or merchant onboarding publicly.
