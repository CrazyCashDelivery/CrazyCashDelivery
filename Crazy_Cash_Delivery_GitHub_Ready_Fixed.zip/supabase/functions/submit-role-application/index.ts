import { withSupabase } from "npm:@supabase/server";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const validPhone = (value: string): boolean => {
  const digits = value.replace(/\D/g, "");
  return digits.length >= 10 && digits.length <= 15;
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  return withSupabase({ auth: "user" }, async (innerReq, ctx) => {
    try {
      const userId = ctx.userClaims?.sub;
      if (!userId) return json({ error: "Sign in is required." }, 401);
      if (ctx.userClaims?.is_anonymous === true) {
        return json({ error: "Create a registered account before applying to become a driver or merchant." }, 403);
      }

      const body = await innerReq.json();
      const role = body?.requested_role;
      const details = body?.application_details;
      if (role !== "driver" && role !== "merchant") {
        return json({ error: "Choose driver or merchant." }, 400);
      }
      if (!details || typeof details !== "object" || Array.isArray(details)) {
        return json({ error: "Application details are required." }, 400);
      }

      const required = role === "driver"
        ? ["full_name", "phone", "vehicle_type", "city"]
        : ["business_name", "contact_name", "phone", "business_category", "city", "business_address"];
      for (const field of required) {
        if (typeof details[field] !== "string" || !details[field].trim()) {
          return json({ error: `Please provide ${field.replaceAll("_", " ")}.` }, 400);
        }
        if (details[field].length > 200) {
          return json({ error: "One or more fields are too long." }, 400);
        }
      }
      // Enforce the same phone rule on the server; client-side checks are not a security boundary.
      if (!validPhone(details.phone)) {
        return json({ error: "Enter a valid phone number with 10 to 15 digits." }, 400);
      }

      const safeDetails: Record<string, string> = {};
      for (const field of required) safeDetails[field] = details[field].trim();

      const { data, error } = await ctx.supabase
        .from("role_applications")
        .insert({
          user_id: userId,
          requested_role: role,
          application_details: safeDetails,
          status: "pending",
        })
        .select("id, requested_role, status, submitted_at")
        .single();

      if (error) {
        if (error.code === "23505") {
          return json({ error: "You already have an open application for this role." }, 409);
        }
        console.error("Role application insert failed:", error.message);
        return json({ error: "We couldn't submit your application. Please try again." }, 500);
      }
      return json({ application: data }, 201);
    } catch (error) {
      console.error("Role application request failed:", error);
      return json({ error: "Invalid request. Please check your information and try again." }, 400);
    }
  })(req);
});
