const fs = require('node:fs');

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Error(`${file} is missing or invalid JSON: ${error.message}`);
  }
}

const pkg = readJson('package.json');
const app = readJson('app.json').expo;
const eas = readJson('eas.json');
const errors = [];
const requiredScripts = ['start', 'ios', 'android', 'typecheck', 'check:syntax', 'test:pricing', 'test:validation', 'qa'];
const requiredPackages = ['expo', 'expo-router', 'react', 'react-native', '@supabase/supabase-js'];

if (!app?.name || !app?.slug || !app?.scheme || !app?.version) {
  errors.push('app.json must define Expo name, slug, scheme, and version.');
}
if (!app?.ios?.bundleIdentifier) errors.push('app.json is missing ios.bundleIdentifier.');
if (!app?.android?.package) errors.push('app.json is missing android.package.');
if (app?.ios?.bundleIdentifier && app?.android?.package && app.ios.bundleIdentifier !== app.android.package) {
  errors.push('iOS bundleIdentifier and Android package should match for this app.');
}
for (const name of requiredScripts) {
  if (!pkg.scripts?.[name]) errors.push(`package.json is missing script: ${name}`);
}
for (const name of requiredPackages) {
  if (!pkg.dependencies?.[name]) errors.push(`package.json is missing dependency: ${name}`);
}
if (!eas?.build?.preview || !eas?.build?.production) {
  errors.push('eas.json must define preview and production build profiles.');
}
if (eas?.build?.preview?.android?.buildType !== 'apk') {
  errors.push('The preview Android profile must produce an APK for internal testing.');
}

if (errors.length) {
  for (const error of errors) process.stderr.write(`Configuration error: ${error}\n`);
  process.exitCode = 1;
} else {
  process.stdout.write('Configuration check passed: package, Expo app, and EAS build settings are valid JSON and internally consistent.\n');
  process.stdout.write('Note: this does not verify installed dependencies, native compilation, signing, or cloud build success.\n');
}
