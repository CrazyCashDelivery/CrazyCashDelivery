const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');

const source = fs.readFileSync('lib/pricing.ts', 'utf8');
const compiled = ts.transpile(source, {
  module: ts.ModuleKind.CommonJS,
  target: ts.ScriptTarget.ES2022,
});
const sandbox = { exports: {}, module: { exports: {} } };
vm.runInNewContext(compiled, sandbox);
const pricing = sandbox.exports;
let passed = 0;
function equal(actual, expected, label) {
  if (actual !== expected) throw new Error(`${label}: expected ${expected}, received ${actual}`);
  passed += 1;
}
function throws(callback, label) {
  let didThrow = false;
  try { callback(); } catch { didThrow = true; }
  if (!didThrow) throw new Error(`${label}: expected an error`);
  passed += 1;
}

for (const [subtotal, expected] of [[0,199],[1999,199],[2000,299],[4999,299],[5000,399],[9999,399],[10000,499]]) {
  equal(pricing.getServiceFeeCents(subtotal), expected, `service fee at ${subtotal} cents`);
}
for (const [miles, expected] of [[0,399],[2,399],[2.001,599],[5,599],[5.001,799],[8,799],[8.001,999],[12,999],[12.001,1299],[15,1299],[15.001,null]]) {
  equal(pricing.getDeliveryFeeCents(miles), expected, `delivery fee at ${miles} miles`);
}
const quote = pricing.calculatePricingQuote({ subtotalCents: 5000, roadDistanceMiles: 5, routeVerified: true });
equal(quote.totalBeforeTipCents, 5998, 'pre-tax quote total');
equal(quote.driverDeliveryShareCents, 479, 'driver receives 80 percent');
equal(quote.driverDeliveryShareCents + quote.platformDeliveryShareCents, 599, 'delivery split reconciles');
const farQuote = pricing.calculatePricingQuote({ subtotalCents: 5000, roadDistanceMiles: 16, routeVerified: true });
equal(farQuote.requiresManualQuote, true, 'over-15-mile manual quote');
equal(farQuote.totalBeforeTipCents, null, 'no invented total for manual quote');
throws(() => pricing.calculatePricingQuote({ subtotalCents: 5000, roadDistanceMiles: 3, routeVerified: false }), 'unverified route rejected');
throws(() => pricing.getServiceFeeCents(-1), 'negative subtotal rejected');

console.log(`Pricing tests passed: ${passed}; failed: 0`);
