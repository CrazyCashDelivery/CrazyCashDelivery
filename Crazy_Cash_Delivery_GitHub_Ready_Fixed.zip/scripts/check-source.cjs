const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');

const ignored = new Set(['node_modules', '.expo', '.git', 'dist', 'build']);
const files = [];
function collect(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.isDirectory() && ignored.has(entry.name)) continue;
    const fullPath = path.join(directory, entry.name);
    if (entry.isDirectory()) collect(fullPath);
    else if (/\.(ts|tsx)$/.test(entry.name)) files.push(fullPath);
  }
}

collect(process.cwd());
let errors = 0;
for (const file of files) {
  const result = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
    fileName: file,
    reportDiagnostics: true,
    compilerOptions: {
      jsx: ts.JsxEmit.ReactJSX,
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
    },
  });
  for (const diagnostic of result.diagnostics ?? []) {
    if (diagnostic.category !== ts.DiagnosticCategory.Error) continue;
    errors += 1;
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n');
    process.stderr.write(`${file}: ${message}\n`);
  }
}

if (errors) {
  process.stderr.write(`Source syntax check failed: ${errors} error(s) across ${files.length} TypeScript file(s).\n`);
  process.exitCode = 1;
} else {
  process.stdout.write(`Source syntax check passed: ${files.length} TypeScript file(s); 0 syntax errors.\n`);
  process.stdout.write('Note: this transpile check is not a full TypeScript type-check. Run npm run typecheck for that.\n');
}
