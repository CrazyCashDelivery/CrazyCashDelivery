const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');

const source = fs.readFileSync('lib/validation.ts', 'utf8');
const compiled = ts.transpile(source, { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 });
const sandbox = { exports: {}, module: { exports: {} } };
vm.runInNewContext(compiled, sandbox);
const validation = sandbox.exports;
let passed = 0;
function equal(actual, expected, label) {
  if (actual !== expected) throw new Error(`${label}: expected ${expected}, received ${actual}`);
  passed += 1;
}
const driver = { full_name: ' Alex Driver ', phone: '904-555-0100', vehicle_type: 'Car', city: 'Jacksonville' };
equal(validation.validateDriverApplication(driver), null, 'valid driver application');
equal(validation.validateDriverApplication({ ...driver, full_name: '  ' }), 'Complete all driver application fields.', 'blank driver name rejected');
equal(validation.validateDriverApplication({ ...driver, phone: '12345' }), 'Enter a valid phone number with 10 to 15 digits.', 'invalid driver phone rejected');
const merchant = { business_name: 'Store', contact_name: 'Owner', phone: '9045550100', business_category: 'Grocery', city: 'Jacksonville', business_address: '1 Main St' };
equal(validation.validateMerchantApplication(merchant), null, 'valid merchant application');
equal(validation.validateMerchantApplication({ ...merchant, business_address: '' }), 'Complete all merchant application fields.', 'missing merchant address rejected');
equal(validation.validateMerchantApplication({ ...merchant, phone: '555' }), 'Enter a valid phone number with 10 to 15 digits.', 'invalid merchant phone rejected');
for (const [value, expected] of [['4.99', 4.99], ['0.01', 0.01], ['0', null], ['-2', null], ['2.999', null], ['abc', null], ['100001', null], [' 12.5 ', 12.5]]) {
  equal(validation.parseCatalogPrice(value), expected, `catalog price ${JSON.stringify(value)}`);
}
console.log(`Validation tests passed: ${passed}; failed: 0`);
