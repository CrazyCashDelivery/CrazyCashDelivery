export type DriverApplication = {
  full_name: string;
  phone: string;
  vehicle_type: string;
  city: string;
};

export type MerchantApplication = {
  business_name: string;
  contact_name: string;
  phone: string;
  business_category: string;
  city: string;
  business_address: string;
};

function clean(value: string): string {
  return value.trim();
}

function validPhone(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  return digits.length >= 10 && digits.length <= 15;
}

export function validateDriverApplication(input: DriverApplication): string | null {
  const fields = [input.full_name, input.phone, input.vehicle_type, input.city];
  if (fields.some((value) => !clean(value))) return 'Complete all driver application fields.';
  if (!validPhone(input.phone)) return 'Enter a valid phone number with 10 to 15 digits.';
  return null;
}

export function validateMerchantApplication(input: MerchantApplication): string | null {
  const fields = [
    input.business_name,
    input.contact_name,
    input.phone,
    input.business_category,
    input.city,
    input.business_address,
  ];
  if (fields.some((value) => !clean(value))) return 'Complete all merchant application fields.';
  if (!validPhone(input.phone)) return 'Enter a valid phone number with 10 to 15 digits.';
  return null;
}

export function parseCatalogPrice(value: string): number | null {
  const normalized = value.trim();
  if (!/^\d+(?:\.\d{1,2})?$/.test(normalized)) return null;
  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 100000) return null;
  return Math.round(amount * 100) / 100;
}
