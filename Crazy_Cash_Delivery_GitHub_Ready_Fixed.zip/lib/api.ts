import { supabase } from './supabase';

function getResponseMessage(payload: unknown): string | undefined {
  if (payload && typeof payload === 'object' && 'error' in payload && typeof (payload as any).error === 'string') return (payload as any).error;
  if (payload && typeof payload === 'object' && 'message' in payload && typeof (payload as any).message === 'string') return (payload as any).message;
  return undefined;
}

export async function callFunction<T = any>(name: string, options: { method?: string; body?: unknown } = {}): Promise<T> {
  const { data, error } = await supabase.functions.invoke<T>(name, {
    method: (options.method ?? 'GET') as any,
    body: options.body as any,
  });
  if (error) {
    let serverMessage: string | undefined;
    const context = (error as any)?.context;
    if (context && typeof context.clone === 'function') {
      try {
        const payload = await context.clone().json();
        if (typeof payload?.error === 'string') serverMessage = payload.error;
      } catch {
        // Some network errors have no JSON response body.
      }
    }
    const message = serverMessage || error.message || 'The request could not be completed.';
    throw new Error(message);
  }
  const responseMessage = getResponseMessage(data);
  if (responseMessage && data && typeof data === 'object' && 'error' in (data as any)) throw new Error(responseMessage);
  return data as T;
}

export async function submitRoleApplication(role: 'driver' | 'merchant', application_details: Record<string,string>) {
  return callFunction('submit-role-application', { method: 'POST', body: { requested_role: role, application_details } });
}

export async function getFunction<T = any>(name: string, query = ''): Promise<T> {
  const baseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
  const apiKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
  if (!baseUrl || !apiKey) throw new Error('App configuration is incomplete. Please contact support.');
  if (!/^[a-z0-9-]+$/i.test(name)) throw new Error('Invalid service name.');
  if (query && !query.startsWith('?')) throw new Error('Query parameters must begin with ?.');

  const { data: { session }, error: sessionError } = await supabase.auth.getSession();
  if (sessionError) throw new Error('Your sign-in session could not be checked. Please sign in again.');
  if (!session?.access_token) throw new Error('Sign in to continue.');

  const response = await fetch(`${baseUrl.replace(/\/$/, '')}/functions/v1/${name}${query}`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: apiKey,
      Accept: 'application/json',
    },
  });
  const raw = await response.text();
  let data: any = null;
  if (raw) {
    try { data = JSON.parse(raw); }
    catch { throw new Error(response.ok ? 'The service returned an unreadable response.' : `The request failed (${response.status}). Please try again.`); }
  }
  if (!response.ok || data?.error) {
    throw new Error(getResponseMessage(data) || `The request could not be completed (${response.status}).`);
  }
  return data as T;
}

export async function quoteDeliveryRoute(order_id: string) {
  return callFunction<{
    order_id: string;
    distance_miles: number;
    delivery_fee: string;
    subtotal: number;
    service_fee: number;
    estimated_total_before_tax: number;
    currency: string;
    checkout_ready: false;
    payment_status: string;
    message: string;
  }>('quote-delivery-route', { method: 'POST', body: { order_id } });
}
