/**
 * Crazy Cash Delivery's agreed customer fee schedule.
 *
 * This module is deliberately pure: the caller must supply a verified ROAD
 * distance (not a straight-line/GPS estimate). The server must recalculate
 * and persist every quote; client-side results are display-only.
 */

export type PricingQuote = {
  subtotalCents: number;
  roadDistanceMiles: number;
  deliveryFeeCents: number | null;
  serviceFeeCents: number;
  totalBeforeTipCents: number | null;
  driverDeliveryShareCents: number | null;
  platformDeliveryShareCents: number | null;
  requiresManualQuote: boolean;
  quoteSource: 'verified_road_distance';
};

function assertNonNegativeFinite(value: number, label: string): void {
  if (!Number.isFinite(value) || value < 0) {
    throw new Error(`${label} must be a non-negative finite number.`);
  }
}

export function getServiceFeeCents(subtotalCents: number): number {
  if (!Number.isSafeInteger(subtotalCents) || subtotalCents < 0) {
    throw new Error('Subtotal must be a non-negative integer number of cents.');
  }
  if (subtotalCents < 2_000) return 199;
  if (subtotalCents < 5_000) return 299;
  if (subtotalCents < 10_000) return 399;
  return 499;
}

export function getDeliveryFeeCents(roadDistanceMiles: number): number | null {
  assertNonNegativeFinite(roadDistanceMiles, 'Road distance');
  if (roadDistanceMiles <= 2) return 399;
  if (roadDistanceMiles <= 5) return 599;
  if (roadDistanceMiles <= 8) return 799;
  if (roadDistanceMiles <= 12) return 999;
  if (roadDistanceMiles <= 15) return 1_299;
  // Beyond 15 miles requires a separately approved zone/extra-distance quote.
  return null;
}

export function calculatePricingQuote(input: {
  subtotalCents: number;
  roadDistanceMiles: number;
  routeVerified: boolean;
}): PricingQuote {
  if (!input.routeVerified) {
    throw new Error('A verified driving-route distance is required before pricing.');
  }
  if (!Number.isSafeInteger(input.subtotalCents) || input.subtotalCents < 0) {
    throw new Error('Subtotal must be a non-negative integer number of cents.');
  }
  assertNonNegativeFinite(input.roadDistanceMiles, 'Road distance');

  const serviceFeeCents = getServiceFeeCents(input.subtotalCents);
  const deliveryFeeCents = getDeliveryFeeCents(input.roadDistanceMiles);
  const requiresManualQuote = deliveryFeeCents === null;
  const driverDeliveryShareCents = requiresManualQuote
    ? null
    : Math.round((deliveryFeeCents * 80) / 100);
  const platformDeliveryShareCents = requiresManualQuote
    ? null
    : deliveryFeeCents - (driverDeliveryShareCents as number);

  return {
    subtotalCents: input.subtotalCents,
    roadDistanceMiles: input.roadDistanceMiles,
    deliveryFeeCents,
    serviceFeeCents,
    totalBeforeTipCents: requiresManualQuote
      ? null
      : input.subtotalCents + serviceFeeCents + (deliveryFeeCents as number),
    driverDeliveryShareCents,
    platformDeliveryShareCents,
    requiresManualQuote,
    quoteSource: 'verified_road_distance',
  };
}
