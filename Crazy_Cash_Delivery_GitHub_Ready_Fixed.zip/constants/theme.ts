export const colors = {
  background: '#090909',
  surface: '#171717',
  surfaceRaised: '#222222',
  gold: '#D6A72C',
  goldLight: '#F3D77A',
  text: '#FFFFFF',
  muted: '#A7A7A7',
  border: '#343434',
  danger: '#E35D5B',
  success: '#55B982',
};
