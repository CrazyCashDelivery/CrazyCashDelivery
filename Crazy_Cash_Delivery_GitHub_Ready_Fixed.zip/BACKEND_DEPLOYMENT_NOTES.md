# Crazy Cash Delivery — backend deployment notes

Date: 2026-11-05

## Confirmed active Supabase changes

- `create-order-request` Edge Function: active version 3. The function calculates the service fee from server-queried catalog prices and stores it in `orders.service_fee`. It still creates an order request only; it does not create a payment or set a final total.
- `customer-order-tracking` Edge Function: active version 4. Its order response includes `service_fee` and the verified `distance_miles` field, and supports retrieval by the authenticated user session, including a guest's anonymous session on the same device.
- Database migration: added `public.orders.service_fee NUMERIC(10,2) NOT NULL DEFAULT 0 CHECK (service_fee >= 0)`.

## Pricing policy

- Item subtotal under $20: $1.99 service fee.
- $20 to under $50: $2.99 service fee.
- $50 to under $100: $3.99 service fee.
- $100 and above: $4.99 service fee.
- Delivery distance fee is not calculated until a trusted server-side driving route has been verified.
- No final total or payment authorization is created by the current order-request endpoint.

## Not completed

- Google Routes API credential configuration and a live end-to-end route-quote test. The server-side quote function is deployed, but it fails closed until `GOOGLE_MAPS_API_KEY` is configured.
- Stripe PaymentSheet, PaymentIntent authorization/capture, webhook handling, refunds, and sandbox checkout.
- SMS phone verification, SMS/email/push delivery, live GPS, and automatic SOS notifications.
- Native dependency installation, complete TypeScript typecheck, Expo/EAS build, and device QA.

## Security

- Never put Supabase service-role keys, Stripe secret keys, or routing-provider secrets in the mobile app or this repository.
- Guest order history is bound to the guest's authenticated anonymous session. Clearing app data or losing that session may make the guest account unrecoverable.
- No live payments were enabled by this deployment.

## Verified driving-route quotes (deployed)

- Edge Function: `quote-delivery-route` (active version 1, JWT verification enabled).
- `customer-order-tracking` is active version 4 and now returns `distance_miles` so the order screen can show the saved route distance.
- The customer can request a quote from the order-history screen for a pending order.
- The function verifies the signed-in customer owns the order, sends the stored pickup and delivery addresses to Google Routes API using `DRIVE`, and calculates the fee from the returned road distance.
- Delivery fee bands: up to 2 mi $3.99; over 2–5 mi $5.99; over 5–8 mi $7.99; over 8–12 mi $9.99; over 12–15 mi $12.99. More than 15 driving miles requires manual service-zone review.
- It stores verified `distance_miles` and `delivery_fee`, but deliberately leaves `total_amount` null and `payment_status` as `awaiting_quote`. It does not create a payment or charge a customer. Tax calculation and payment authorization remain unfinished.
- Required server-side configuration: set `GOOGLE_MAPS_API_KEY` as a Supabase Edge Function secret. Do not put this key in the mobile app, `.env` file shipped to customers, GitHub, or chat. The function fails closed with `ROUTE_PROVIDER_NOT_CONFIGURED` until the secret is configured.
- Ensure the Google Cloud project has Routes API enabled and restrict the key to the Routes API.

## Verified delivery route quotes (deployed)

- Edge Function: `quote-delivery-route` (active version 1, JWT verification enabled).
- `customer-order-tracking` is active version 4 and returns the saved `distance_miles`.
- The order-history screen lets a customer request a quote for a pending order.
- The function verifies that the authenticated customer owns the order, then uses the saved pickup and delivery addresses with Google Routes API in driving mode. Customers cannot override the addresses in the quote request.
- Delivery fee bands: up to 2 mi $3.99; over 2–5 mi $5.99; over 5–8 mi $7.99; over 8–12 mi $9.99; over 12–15 mi $12.99. More than 15 driving miles requires manual service-zone review.
- It saves verified `distance_miles` and `delivery_fee`, but deliberately leaves `total_amount` null and `payment_status` as `awaiting_quote`. It does not authorize or capture payment.
- Required server-side configuration: set `GOOGLE_MAPS_API_KEY` as a Supabase Edge Function secret. The function fails closed until this secret is configured. Ensure Routes API is enabled and restrict the key to Routes API use. Never put the key in the mobile app, `.env` shipped to customers, GitHub, or chat.

## Payment lifecycle audit (2026-11-05)

- Current merchant and driver Edge Functions gate dispatch on `payment_status=paid` (or COD). That does not support the agreed manual authorization → driver assignment → capture sequence. The two workflows must be revised together, with a server-side idempotent capture after a driver is assigned and a safe rollback/hold path if capture fails.
- Stripe sandbox Tax Settings were inspected read-only: status is `pending` because `head_office` is missing. The sandbox currently has no tax registrations. Do not enable automatic tax or customer checkout until the business supplies verified tax setup and active applicable registrations, then a sandbox tax calculation is verified.
- Stripe PaymentSheet and server-side PaymentIntent functions/webhooks are not implemented. No Stripe objects were created and no payments were taken.
- See `PAYMENT_CHECKOUT_READINESS.md` for the implementation sequence and test matrix.

## Finalization pass — 2026-11-06

- Updated the driver portal POST helper to use the shared `callFunction` API wrapper. This ensures driver actions surface structured Edge Function error messages consistently instead of only showing the generic Supabase invocation error.
- Re-ran TypeScript transpile/syntax validation across all 18 `.ts`/`.tsx` files: zero syntax errors.
- Attempted dependency installation again (`npm install --ignore-scripts --no-audit --no-fund --prefer-offline`); it timed out. Therefore a full `tsc --noEmit`, Expo prebuild, EAS build, and device QA remain unverified.
- No Supabase production function or database changes were deployed in this pass. No Stripe payment intents, captures, refunds, or live charges were created.
- Checkout remains disabled until tax setup is complete and the merchant/driver/payment state machine is changed and verified as one atomic server-side workflow.
