import { Pressable, Text, ActivityIndicator } from 'react-native';
import { colors } from '@/constants/theme';
export function PrimaryButton({ title, onPress, loading=false, disabled=false }: {
  title:string; onPress:()=>void; loading?:boolean; disabled?:boolean
}) {
  return <Pressable onPress={onPress} disabled={disabled||loading}
    style={{ minHeight:52, borderRadius:14, backgroundColor:colors.gold, alignItems:'center', justifyContent:'center', paddingHorizontal:18, opacity:disabled?0.5:1 }}>
    {loading ? <ActivityIndicator color="#090909" /> : <Text style={{ color:'#090909', fontWeight:'900', fontSize:16 }}>{title}</Text>}
  </Pressable>;
}
