import { ScrollView, Text, View, Pressable } from 'react-native';
import { router } from 'expo-router';
import { Brand } from '@/components/Brand';
import { colors } from '@/constants/theme';

type Props = { title:string; subtitle:string; items:string[]; note:string };
export function PortalScreen({title,subtitle,items,note}:Props) {
  return <ScrollView style={{flex:1,backgroundColor:colors.background}} contentContainerStyle={{padding:24,paddingTop:58,gap:22}}>
    <Brand compact />
    <View style={{gap:8}}>
      <Text style={{color:colors.gold,fontSize:12,fontWeight:'900',letterSpacing:2}}>CRAZY CASH DELIVERY</Text>
      <Text style={{color:colors.text,fontSize:28,fontWeight:'900'}}>{title}</Text>
      <Text style={{color:colors.muted,lineHeight:21}}>{subtitle}</Text>
    </View>
    {items.map((item,i)=><View key={item} style={{backgroundColor:colors.surface,borderColor:colors.border,borderWidth:1,borderRadius:14,padding:17,flexDirection:'row',gap:12,alignItems:'center'}}>
      <Text style={{color:colors.gold,fontWeight:'900',fontSize:17}}>{String(i+1).padStart(2,'0')}</Text>
      <Text style={{color:colors.text,fontWeight:'700',flex:1}}>{item}</Text>
    </View>)}
    <View style={{backgroundColor:colors.surfaceRaised,borderRadius:14,padding:16,gap:7}}>
      <Text style={{color:colors.gold,fontWeight:'900'}}>SETUP STATUS</Text>
      <Text style={{color:colors.muted,lineHeight:20}}>{note}</Text>
    </View>
    <Pressable onPress={()=>router.push('/roles')} style={{padding:15,borderRadius:12,borderWidth:1,borderColor:colors.gold}}>
      <Text style={{color:colors.goldLight,textAlign:'center',fontWeight:'900'}}>Back to portal selection</Text>
    </Pressable>
  </ScrollView>;
}
