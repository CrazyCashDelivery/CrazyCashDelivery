import { Text, View } from 'react-native';
import { colors } from '@/constants/theme';
export function Brand({ compact = false }: { compact?: boolean }) {
  return <View style={{ alignItems:'center', gap:4 }}>
    <Text style={{ color:colors.gold, fontSize:compact?25:34, fontWeight:'900', letterSpacing:1 }}>CRAZY CASH</Text>
    <Text style={{ color:colors.text, fontSize:compact?11:13, fontWeight:'700', letterSpacing:5 }}>DELIVERY</Text>
  </View>;
}
