# Crazy Cash Delivery — connected Expo app milestone

Expo SDK 54 / React Native 0.81 app for iOS and Android. Black-and-gold branded customer, driver, merchant, and administrator screens now call the existing authenticated Supabase Edge Functions.

## Run locally
1. Install Node.js LTS.
2. Copy `.env.example` to `.env` and use the Supabase URL and public publishable/anon key shown in `.env.example` (replace the key placeholder). The source package intentionally excludes `.env`; never commit local environment files.
3. Never put a Supabase service-role key, Stripe secret key, or SMS provider secret in this app.
4. Run `npm install`, then `npx expo start`.
5. Open with Expo Go or a development build.

## Connected mobile workflows
- Supabase email/password sign-up and sign-in.
- Customer: browse the published merchant directory and available catalog items; submit an authenticated order request; view own order history and tracking fields; cancel eligible pending orders; submit SOS reports.
- Driver: submit driver application; request online/offline availability; fetch offers and active deliveries; accept/decline offers; advance delivery status.
- Merchant: submit merchant application; fetch incoming orders; accept/reject, prepare, and mark orders ready; create and view catalog items.
- Admin: load operations dashboard; review SOS and fraud flags; approve/reject driver and merchant applications.

All privileged actions continue through authenticated Edge Functions; the mobile client does not use a Supabase service-role key.

## Not production-ready yet
- Guest order requests use Supabase anonymous authentication. The customer screen collects a guest name and phone number (email optional), starts an anonymous session, and sends those fields to `create-order-request`. Supabase Anonymous Sign-ins must be enabled in the project Auth settings for this path to work. Guests should not sign out or clear app data before completing their order because anonymous sessions cannot be recovered on another device. This is an order-request flow, not paid checkout.
- Guest checkout now detects an already-restored anonymous session as a guest (not as a registered account) and continues to show the required guest contact fields. This prevents returning guest users from submitting an order request with missing name/phone details after reopening the app.
- SMS phone-number verification is not yet wired into sign-up; the phone field is currently saved as profile metadata only.
- The current database has no published merchants/catalog items, so customer store browsing will be empty until approved merchants are onboarded and add their first product. Adding the first product automatically publishes the approved merchant in the customer directory.
- The deployed `create-order-request` Edge Function calculates the service fee on the server from catalog prices and stores it in `orders.service_fee`. The deployed customer order-history function returns the service fee and permits an authenticated guest session to view its own orders on the same device session. Delivery fee and final total remain pending until a server-side driving-route provider is configured.
- Order creation currently submits a request only. `checkout_ready` is false and Stripe checkout is not connected. A pure pricing rules module (`lib/pricing.ts`) encodes the agreed distance bands, service-fee tiers, and 80/20 delivery-fee split. The customer cart displays a service-fee estimate; the backend independently calculates and stores the authoritative service fee. Delivery fees and final totals remain withheld until a verified road distance is supplied. The quote helper refuses to quote without a verified road distance and requires a manual quote beyond 15 miles. It is display/business logic only: the trusted backend must independently calculate and persist the final quote before checkout can be enabled. Do not charge customers.
- Driver and merchant accounts must be approved by an authorized administrator before operational actions work.
- Admin access requires an authorized user in `admin_users`.
- SMS phone verification, SMS/email/push delivery providers, live GPS permission/background tracking, emergency dispatch to 911/support/contacts, VIP billing, refunds, Stripe Connect payouts, and store deployment remain outstanding.
- SOS submission records an event; it does not contact emergency services or alert support automatically. Call 911 directly in an emergency.

## Pricing rules and checkout status
- Delivery fee: up to 2 mi $3.99; over 2–5 mi $5.99; over 5–8 mi $7.99; over 8–12 mi $9.99; over 12–15 mi $12.99; beyond 15 mi requires a separately approved quote.
- Service fee by item subtotal: under $20 $1.99; $20–under $50 $2.99; $50–under $100 $3.99; $100+ $4.99.
- Delivery-fee allocation: driver 80%, platform 20%; tips remain 100% with the driver.
- The quote helper accepts only an explicitly verified driving-route distance. Never substitute straight-line distance or a guessed mileage.

## Configuration and security
- Public client uses only `EXPO_PUBLIC_SUPABASE_URL` and `EXPO_PUBLIC_SUPABASE_ANON_KEY` (or publishable key).
- Never add Stripe secret keys, Twilio auth tokens, or Supabase service-role keys to Expo environment variables.
- RLS remains enabled. Do not bypass RLS or write directly to protected tables from the client.
- Test with dedicated accounts and test data before production release.

## Internal build preparation
- `eas.json` includes an internal preview profile (Android APK) and a production profile for future store builds.
- Before building, sign in to an Expo account with `npx eas-cli@latest login`, configure the project with `npx eas-cli@latest build:configure` if prompted, and add the Supabase public URL and publishable key as EAS environment variables for the intended build environment.
- Create an internal preview with `npx eas-cli@latest build --platform android --profile preview` or `npx eas-cli@latest build --platform ios --profile preview`.
- A successful cloud build and device testing are still required; this source archive is not an installable app binary.


### Verified route quotes

The order-history screen includes a **Get verified delivery quote** action for pending orders. It calls the server-side `quote-delivery-route` function, which uses Google Routes API road distance and the configured delivery-fee bands. Configure `GOOGLE_MAPS_API_KEY` as a Supabase Edge Function secret before this action can return a quote. The key must never be bundled in the app. The route quote is informational only: tax, final total, and payment authorization are not yet implemented, so checkout remains disabled.

## Payment checkout readiness audit

See [`PAYMENT_CHECKOUT_READINESS.md`](./PAYMENT_CHECKOUT_READINESS.md) for the current sandbox payment design, the verified tax-configuration blocker, and the order-lifecycle change required before PaymentSheet can be enabled. The current live order workflows still require `paid` before driver matching; this must be changed safely to support authorization first and capture after driver assignment. No payments are enabled.

## Local source checks
After dependencies are installed, run:

- `npm run check:config` — validates package, Expo app, and EAS build configuration consistency.
- `npm run check:syntax` — transpile-checks all TypeScript/TSX source files for syntax errors. This is not a full type-check.
- `npm run test:pricing` — runs the fee schedule and driver/platform split tests.
- `npm run test:validation` — runs driver/merchant application and catalog input validation tests.
- `npm run qa` — runs configuration, source syntax, pricing, and application/catalog validation checks together.
- `npm run typecheck` — runs the full TypeScript compiler check; this requires the complete dependency installation.


## Dependency installation blocker
The current build runner cannot resolve `registry.npmjs.org` (`EAI_AGAIN`), and its npm cache is empty. This is an execution-environment DNS/network issue, not something an app-code edit can fix. See [`NETWORK_BLOCKER_RECOVERY.md`](./NETWORK_BLOCKER_RECOVERY.md) for the verified diagnostics and recovery commands to run on a network-enabled computer or CI runner. No full typecheck or native build has passed yet.
