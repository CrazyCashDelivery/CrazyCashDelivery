# Crazy Cash Delivery — GitHub source upload

## Goal
Upload the prepared app source archive to the work branch so GitHub Actions can install dependencies and run the full checks with working network access.

## Safe destination
- Repository: `CrazyCashDelivery/CrazyCashDelivery`
- Branch: `mobile-app-work`
- Do not upload this work to `main`.

## Easiest upload method
1. Download `Crazy_Cash_Delivery_GitHub_Ready.zip` from this handoff.
2. Open the repository on GitHub and select the `mobile-app-work` branch using the branch selector.
3. Choose **Add file → Upload files**.
4. Upload the ZIP file into the repository's top-level folder (the repository root).
5. Commit the upload to `mobile-app-work` with a message such as `Add Crazy Cash Delivery mobile app source archive`.
6. Open the repository's **Actions** tab and select the newest **Crazy Cash Delivery mobile app checks** run.

The existing workflow is configured to detect a ZIP at the repository root, extract its contents, install packages, run `npm run qa`, run `npm run typecheck`, run Expo Doctor, and verify Expo bundles. You do not need to extract the archive yourself before uploading it.

## If using GitHub Codespaces instead
Open a Codespace for `mobile-app-work`, upload the ZIP into the workspace root, then run:

```bash
unzip -o Crazy_Cash_Delivery_GitHub_Ready.zip -d /tmp/ccd-source
cp -a /tmp/ccd-source/. .
npm install --no-audit --no-fund
git status
```

Confirm the current branch is `mobile-app-work` and that no `.env`, credentials, `node_modules`, build output, or service-role keys are included. Then commit and push the source to `mobile-app-work`.

## Current verification
- Expo/EAS configuration check: passed.
- TypeScript/TSX syntax check: 20 files, zero syntax errors.
- Pricing tests: 25/25 passed.
- Validation tests: 14/14 passed.
- Full TypeScript typecheck, Expo Doctor, and native builds: not yet verified because dependencies could not be installed in the restricted local environment.

## Safety boundary
No production backend changes, RLS changes, live payment processing, or customer charges are part of this upload. Do not add secrets to the repository. Configure any required credentials later using the appropriate secret manager.
