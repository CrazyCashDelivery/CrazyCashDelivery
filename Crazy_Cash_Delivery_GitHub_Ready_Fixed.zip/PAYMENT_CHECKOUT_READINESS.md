# Crazy Cash Delivery — payment and checkout readiness

Audit date: 2026-11-05

## Decision: sandbox-only PaymentIntent authorization/capture

Crazy Cash Delivery sells physical goods and delivery services in a mobile app. The intended business sequence is:

1. Verify the order, catalog subtotal, delivery address, and road-route fee on the server.
2. Calculate applicable tax only after the business tax setup is confirmed.
3. Create a Stripe **sandbox** PaymentIntent with `capture_method=manual` and dynamic payment methods enabled. The client receives only the PaymentIntent client secret.
4. The customer confirms the authorization in Stripe React Native PaymentSheet. A successful authorization should leave the PaymentIntent capturable; it is not yet a captured charge.
5. The merchant accepts and prepares the order.
6. A driver accepts the ready order. The backend atomically assigns the driver, then captures the authorized PaymentIntent server-side using an idempotency key. If capture fails, the assignment must be rolled back or the order safely held for review; it must not be dispatched as paid.
7. Signed Stripe webhooks reconcile authorization, capture, cancellation, failure, refund, and dispute events. Webhooks—not a mobile success screen—are the source of truth.
8. If the merchant rejects or no driver can be assigned before authorization expiry, cancel the PaymentIntent and release the authorization. Refund captured payments when the applicable cancellation policy requires it.

Cash-on-delivery remains a separate path, capped at $150, with no Stripe PaymentIntent.

## Confirmed blockers from live configuration and code audit

- Stripe sandbox Tax Settings currently return `status=pending` and `head_office` is missing.
- Stripe sandbox currently has **zero tax registrations**. No tax registration was created or changed during this audit.
- Do not enable Stripe Tax automatic calculation until the business confirms its head-office details and the relevant tax registrations are active. Stripe reports no tax collection while settings are pending; a silent zero-tax result is not acceptable for checkout.
- The current `merchant-order-workflow` only reports dispatch-ready when `payment_status=paid` (or the COD status is set).
- The current `driver-delivery-workflow` only lists and accepts orders marked `paid` (or COD). This prevents the planned authorize → assign driver → capture sequence. Both workflows must be updated together with a secure payment-capture step before payment checkout can be enabled.
- Current app package does not include `@stripe/stripe-react-native`; native dependency installation timed out during this attempt, so no native build or device test was possible.
- No Stripe secret or webhook secret was placed in the app or repository. No payment objects were created and no charges were made.

## Required implementation and verification gates

- Add the Expo-compatible Stripe React Native SDK and rebuild native iOS/Android binaries.
- Implement authenticated, customer/order-ownership-checked server functions for creating the manual-capture PaymentIntent, cancelling an authorization, capturing after driver assignment, and refunding eligible captured payments.
- Recalculate every amount server-side from the saved order and verified route; never trust client-supplied totals.
- Store the PaymentIntent ID and idempotency state server-side. Never return or expose Stripe secret keys to the app.
- Add a webhook endpoint with raw-body signature verification and idempotent event processing. Reconcile `payment_intent.amount_capturable_updated`, `payment_intent.succeeded`, `payment_intent.payment_failed`, `payment_intent.canceled`, refund, and dispute events as appropriate.
- Confirm business tax setup with a qualified tax professional; configure the correct head-office details, product tax treatment, and registrations in Stripe. Run a sandbox tax calculation and inspect `taxability_reason` before enabling checkout.
- Test success, 3DS authentication, decline, duplicate submit, cancellation before capture, capture failure, webhook retry/out-of-order delivery, refund, COD, and no-driver cases.
- Keep live mode disabled until all sandbox tests, full type-check, iOS/Android builds, and real-device QA pass.

## Existing confirmed checkout foundation

- `create-order-request` is active and calculates the service fee server-side.
- `quote-delivery-route` is active and calculates delivery fees from verified driving distance, but intentionally leaves `total_amount` unset and checkout disabled.
- Pricing rules remain: service fee $1.99 / $2.99 / $3.99 / $4.99 by subtotal tier; delivery fee $3.99 through 2 mi, $5.99 through 5 mi, $7.99 through 8 mi, $9.99 through 12 mi, and $12.99 through 15 mi; beyond 15 mi requires manual review.
- Driver gets 80% of delivery fee; platform gets 20%; driver keeps 100% of tips.

## Audit boundary

This package is a source handoff, not an installable app. The sandbox tax settings and current Edge Function source were inspected read-only. No production database changes, Edge Function deployments, Stripe mutations, live charges, or customer notifications were performed in this audit.
