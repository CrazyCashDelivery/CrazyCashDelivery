# Crazy Cash Delivery — CI recovery guide

The current ChatGPT build runner cannot resolve the npm registry (`EAI_AGAIN`) and has no cached dependencies. To move dependency installation to a network-enabled runner, the source now includes `.github/workflows/mobile-app-ci.yml`.

## What the workflow does

1. Runs on GitHub-hosted Ubuntu with Node.js 22.
2. Installs packages using the configured npm registry.
3. Runs `npm run qa` (Expo/EAS configuration, TypeScript syntax, pricing, and application validation tests).
4. Runs `npm run typecheck` (the full TypeScript compiler).
5. Runs `expo-doctor` to inspect Expo project compatibility.
6. Uploads the generated `package-lock.json` and readiness report as a workflow artifact.

## Important limitation

The workflow will not run until this source package is committed to a GitHub branch. Its presence in this ZIP does not mean it has run. Review the generated lockfile, add it to source control, and then use the Actions tab to inspect the workflow run. EAS builds still require an Expo account/project configuration and an `EXPO_TOKEN` secret; no token belongs in source code.

## GitHub branch status
The CI workflow file has now been committed to `mobile-app-work` (latest workflow commit `45fd4fdfc450ad37824b76bf5d7caf46aeb7fcef`). The Expo app source itself is still only in the local handoff ZIP and is not present in that GitHub branch. GitHub Actions has not yet completed an app validation run; earlier workflow runs ended before executing any jobs. Keep `main` unchanged.
